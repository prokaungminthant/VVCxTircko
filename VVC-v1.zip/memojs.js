let getFpsInfo = () => {
    let textContent = document.querySelector(`div[style="width: 550px; position: absolute; top: 0px; left: 0px; padding: 10px; pointer-events: none; background-color: rgba(0, 0, 0, 0.8); display: block;"]`).textContent;
    let textArr = textContent.split(" ")
    let newArr = []
    for (let i of textArr) {
        if (i.length >= 1) {
            newArr.push(i)
        }
    }
    return (newArr)
}

fpsArr = getFpsInfo()
console.log(fpsArr[1])
console.log(fpsArr[47])




// 監視対象の要素を取得
const targetNode = document.querySelector('.sc-heudyb.hKPhsI');

// 変更を監視するための設定
const config = { childList: true, subtree: true };

// MutationObserverのコールバック関数を定義
const callback = function (mutationsList, observer) {
    for (let mutation of mutationsList) {
        if (mutation.type === 'childList') {
            mutation.addedNodes.forEach(addedNode => {
                console.log('追加されたノード:', addedNode);
            });
        }
    }
};

// MutationObserverインスタンスを作成し、監視を開始
const observer = new MutationObserver(callback);
observer.observe(targetNode, config);

